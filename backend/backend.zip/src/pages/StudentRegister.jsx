import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../api'

const StudentRegister = () => {
  const navigate = useNavigate()
  const [programs, setPrograms] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  const [formData, setFormData] = useState({
    registration_no: '',
    full_name: '',
    email: '',
    phone: '',
    date_of_birth: '',
    program_id: '',
    password: '',
    confirmPassword: ''
  })

  useEffect(() => {
    loadPrograms()
  }, [])

  const loadPrograms = async () => {
    try {
      const { data } = await api.get('/programs')
      setPrograms(data)
    } catch (err) {
      console.error('Failed to load programs:', err)
    }
  }

  const validateRegistrationNo = (regNo) => {
    if (!regNo) return true; // Optional
    const regex = /^\d{7}$/;
    if (!regex.test(regNo)) {
      return 'Registration number must be exactly 7 digits (YYXXXXX format)';
    }
    const year = parseInt(regNo.substring(0, 2));
    if (year < 21 || year > 30) {
      return 'First 2 digits must be year (21-30)';
    }
    return true;
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match')
      return
    }
    
    if (formData.password.length < 8) {
  setError('Password must be at least 8 characters')
  return
}

    const regValidation = validateRegistrationNo(formData.registration_no)
    if (regValidation !== true) {
      setError(regValidation)
      return
    }

    setLoading(true)

    try {
      await api.post('/student-auth/register', {
        registration_no: formData.registration_no || null,
        full_name: formData.full_name,
        email: formData.email,
        phone: formData.phone,
        date_of_birth: formData.date_of_birth,
        program_id: parseInt(formData.program_id),
        password: formData.password
      })
      setSuccess('Registration request submitted! Please wait for admin approval.')
      setTimeout(() => navigate('/student-login'), 2000)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    }}>
      <div style={{ 
        background: 'white', 
        borderRadius: '16px', 
        padding: '2.5rem', 
        width: '100%', 
        maxWidth: '550px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '64px', height: '64px', background: '#2563eb', borderRadius: '16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontWeight: 'bold', fontSize: '2rem', margin: '0 auto 1rem'
          }}>E</div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '0.5rem' }}>Student Registration</h1>
          <p style={{ color: '#64748b', fontSize: '0.9rem' }}>Request access to EduBase</p>
        </div>

        {error && (
          <div style={{ background: '#fee2e2', color: '#991b1b', padding: '0.75rem', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.875rem' }}>
            {error}
          </div>
        )}

        {success && (
          <div style={{ background: '#d1fae5', color: '#065f46', padding: '0.75rem', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.875rem' }}>
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Registration Number (7 digits: YYXXXXX)</label>
            <input type="text" className="form-input" maxLength={72}
              value={formData.registration_no}
              onChange={(e) => setFormData({...formData, registration_no: e.target.value.replace(/\D/g, '')})}
              placeholder="e.g., 2105001" />
            <small style={{ color: '#64748b', fontSize: '0.75rem' }}>
              First 2 digits: Year (21-30), Next 2 digits: Dept Code, Last 3 digits: Your number
            </small>
          </div>

          <div className="form-group">
            <label className="form-label">Full Name *</label>
            <input type="text" className="form-input" required
              value={formData.full_name}
              onChange={(e) => setFormData({...formData, full_name: e.target.value})}
              placeholder="Enter your full name" />
          </div>

          <div className="form-group">
            <label className="form-label">Email *</label>
            <input type="email" className="form-input" required
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              placeholder="your.email@example.com" />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Phone</label>
              <input type="text" className="form-input"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="Phone number" />
            </div>
            <div className="form-group">
              <label className="form-label">Date of Birth</label>
              <input type="date" className="form-input"
                value={formData.date_of_birth}
                onChange={(e) => setFormData({...formData, date_of_birth: e.target.value})} />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Program *</label>
            <select className="form-select" required
              value={formData.program_id}
              onChange={(e) => setFormData({...formData, program_id: e.target.value})}>
              <option value="">Select your program</option>
              {programs.map(p => (
                <option key={p.program_id} value={p.program_id}>
                  {p.program_name} ({p.degree_level})
                </option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Password *</label>
              <input type="password" className="form-input" required minLength={8}
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                placeholder="Minimum 8 characters" />
            </div>
            <div className="form-group">
              <label className="form-label">Confirm Password *</label>
              <input type="password" className="form-input" required
                value={formData.confirmPassword}
                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                placeholder="Confirm password" />
            </div>
          </div>

          <button type="submit" className="btn btn-primary" 
            style={{ width: '100%', marginTop: '1rem' }} disabled={loading}>
            {loading ? 'Submitting...' : 'Submit Registration Request'}
          </button>
        </form>

        <div style={{ marginTop: '1.5rem', textAlign: 'center', fontSize: '0.875rem', color: '#64748b' }}>
          Already registered? <Link to="/student-login" style={{ color: '#2563eb', fontWeight: '500' }}>Login here</Link>
        </div>
        
        <div style={{ marginTop: '1rem', textAlign: 'center', fontSize: '0.875rem', color: '#64748b' }}>
          <Link to="/login" style={{ color: '#64748b' }}>Admin Login</Link>
        </div>
      </div>
    </div>
  )
}

export default StudentRegister